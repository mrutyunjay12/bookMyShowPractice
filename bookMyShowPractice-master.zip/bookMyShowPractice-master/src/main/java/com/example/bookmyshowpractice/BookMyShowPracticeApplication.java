package com.example.bookmyshowpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowPracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookMyShowPracticeApplication.class, args);
    }

}
