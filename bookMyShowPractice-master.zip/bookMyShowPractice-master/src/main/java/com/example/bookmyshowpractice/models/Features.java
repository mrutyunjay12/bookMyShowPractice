package com.example.bookmyshowpractice.models;

public enum Features {
    _2D,
    _3D,
    DOLBY,


}
