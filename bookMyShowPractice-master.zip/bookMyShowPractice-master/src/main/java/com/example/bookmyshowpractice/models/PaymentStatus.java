package com.example.bookmyshowpractice.models;

public enum PaymentStatus {
    SUCCESS,
    FAILURE
}
