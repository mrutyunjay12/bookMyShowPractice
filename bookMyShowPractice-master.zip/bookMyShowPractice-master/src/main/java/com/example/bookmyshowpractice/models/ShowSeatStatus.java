package com.example.bookmyshowpractice.models;

public enum ShowSeatStatus {
    AVAILABLE,
    BOOKED,
    LOCKED,
    IN_PROCESSING

}
