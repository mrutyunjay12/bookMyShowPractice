package com.example.bookmyshowpractice.models;

public enum TicketStatus {
    BOOKED,
    CANCELLED,
    REFUNDED
}
