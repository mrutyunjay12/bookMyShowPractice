package com.example.bookmyshowpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyPicturePracticeApplicationTests {

    @Test
    void contextLoads() {
    }

}
